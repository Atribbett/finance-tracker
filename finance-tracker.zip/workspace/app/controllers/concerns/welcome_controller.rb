class WelcomeController < ApplicationController
    
    def home
        
    end
    
    def about
        
    end
    
    def pages
        
    end
    
end